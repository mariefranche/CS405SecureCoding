// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Michelle Lewis
// CS 405-R4887

#include <iomanip>
#include <iostream>
#include <string> // Use for getline
#include <cstring> // Use for strcmp function to compare C-style strings
#include <limits>  // Use for numeric limits

int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;

	// TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
	//  even though it is a constant and the compiler buffer overflow checks are on.
	//  You need to modify this method to prevent buffer overflow without changing the account_order
	//  varaible, and its position in the declaration. It must always be directly before the variable used for input.

	const std::string account_number = "CharlieBrown42";
	char user_input[21]; // Increased buffer to 21 so user can enter up to 20 characters
	bool keepRunning = true;  // Control loop so user can keep entering input

	// Menu Loop
	while (keepRunning) {
		std::cout << "Enter a value (Max 20 characters, or 'exit' to quit): ";
		
		// Reads input and ensures input is not beyond 20 characters
		std::cin.getline(user_input, sizeof(user_input));

		// Checks if user wants to exit the menu
		if (strcmp(user_input, "exit") == 0) { 
			keepRunning = false; // exits menu
		}
		else {
			if (std::cin.fail()) {  // if user input was too long
				std::cin.clear();   // clear the error so that input can be entered again
				std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Clears input buffer and discards unwanted characters
				std::cout << "Input exceeded 20 characters.  Please try again." << std::endl;  // Notify user that max character limit was reached
			}
			else {
				std::cout << "You entered: " << user_input << std::endl; // If input was 20 characters or less it will display to the user
				std::cout << "Account Number = " << account_number << std::endl;  // Account number doesn't change and will display to user
			}
		}
	}
	std::cout << "Exiting program.  Good bye." << std::endl;  // Informs user that they are exiting the program
	return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
